// Smooth Navigation
function navigateTo(url) {
    window.location.href = url;
}   